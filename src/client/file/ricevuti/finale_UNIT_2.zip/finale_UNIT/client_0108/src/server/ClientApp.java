package server;

/**
 * Classe che istanzia e fa partire la chat
 * 
 * @author mattia.corradi.tr@gmail.com
 * @version 1.8
 */

public class ClientApp {
    /** 
     * @param args 
     */
    public static void main(String args[]) {
        Login form = new Login();
        form.setVisible(true);
    }
}
